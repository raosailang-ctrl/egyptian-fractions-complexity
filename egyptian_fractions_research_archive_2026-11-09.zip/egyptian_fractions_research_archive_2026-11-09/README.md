# 埃及分数与计算复杂性研究档案

档案日期：2026-11-09  
GitHub： https://github.com/raosailang-ctrl/egyptian-fractions-complexity  
最新研究状态提交：`bbf9c17cf81f7e23963e096b2c83eceb6956e75e`

## 使用说明

1. 先读 `RESEARCH_MASTER_SUMMARY.md`，了解研究对象、推导链、定理和结论边界。
2. 再读 `RESEARCH_STATE.md`，它是本档案的交接状态与下一步任务。
3. `research-outputs/` 保存主要数学报告；`programs/` 保存本轮重点验证程序。
4. 需要继续研究时，先核对 GitHub 默认分支是否已有更新，再按 `RESEARCH_STATE.md` 的 Next step 继续。

## 重要说明

本档案是截至 2026-11-09 的研究快照，不等于经过同行评审的论文。文中区分：已证明的代数恒等式、有限参数实验、启发式观察、尚未证明的猜想。特别是：没有证明一般唯一性，没有证明 P≠NP，也没有证明本项目算法为多项式时间。

本 ZIP 是研究总结与关键文件包，不是 Git 仓库的完整克隆；完整历史、其余程序及所有文件请以 GitHub 仓库为准。
