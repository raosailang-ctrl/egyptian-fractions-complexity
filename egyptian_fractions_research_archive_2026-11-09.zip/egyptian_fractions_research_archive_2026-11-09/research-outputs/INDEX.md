# 主要研究报告索引

| 文件 | 内容 | 状态 |
|---|---|---|
| `K3_QRS_GCD_PARAMETERIZATION_2026-11-08.md` | gcd–互素因子双射、模平方根上界 | 核心证明 |
| `LOCAL_JACOBI_AP_THEOREM_AND_RANK_SURVEY_2026-11-08.md` | 任意固定秩 AP 构造、有限秩调查 | 核心证明+有限计算 |
| `LOCAL_GLOBAL_SIEVE_13_PARAMETERS_2026-11-08.md` | 13组参数局部—全局精确筛 | 有限计算 |
| `ADAPTIVE_MITM_LOCAL_GLOBAL_SIEVE_2026-11-09.md` | 自适应 MITM | 算法+有限实验 |
| `ROOT_TRANSPORT_MITM_LOCAL_GLOBAL_SIEVE_2026-11-09.md` | 平方根集合传输 | 核心引理+有限验证 |
| `GRAY_KERNEL_ROOT_TRANSPORT_2026-11-09.md` | Gray Code 核空间校正公式 | 代数推导+有限验证 |
| `WEIGHTED_JACOBI_CODE_ENUMERATOR_2026-11-09.md` | 带权 MacWilliams 精确计数 | 核心恒等式 |
| `GROUP_ALGEBRA_GLOBAL_SIEVE_2026-11-09.md` | 修正版群代数与 Fourier 展开 | 精确恒等式；旧版有勘误 |
| `CORRECTED_GROUP_ALGEBRA_MITM_2026-11-09.md` | 修正版群代数 MITM 方法 | 方法说明 |
| `CORRECTED_GROUP_ALGEBRA_MITM_RESULTS_2026-11-09.md` | t=7、69 的目标系数实测 | 有限计算 |
| `SYNDROME_ZERO_RESIDUE_DISTRIBUTION_2026-11-09.md` | 六组参数完整余数分布 | 有限计算；推翻低频猜想 |
