# GitHub 原始文件清单

以下文件均保留在项目 GitHub 仓库中。由于本 ZIP 是便于跨对话继承的总结档案，不是完整仓库克隆，程序原文与历史版本请从对应链接获取。

## 核心程序
- https://github.com/raosailang-ctrl/egyptian-fractions-complexity/blob/main/research-outputs/verify_arithmetic_progression_jacobi_sieve.py
- https://github.com/raosailang-ctrl/egyptian-fractions-complexity/blob/main/research-outputs/survey_jacobi_rank.py
- https://github.com/raosailang-ctrl/egyptian-fractions-complexity/blob/main/research-outputs/verify_selected_q_sieve_counts.py
- https://github.com/raosailang-ctrl/egyptian-fractions-complexity/blob/main/research-outputs/verify_local_global_sieve.py
- https://github.com/raosailang-ctrl/egyptian-fractions-complexity/blob/main/research-outputs/adaptive_mitm_local_global_sieve.py
- https://github.com/raosailang-ctrl/egyptian-fractions-complexity/blob/main/research-outputs/root_transport_mitm_local_global_sieve.py
- https://github.com/raosailang-ctrl/egyptian-fractions-complexity/blob/main/research-outputs/gray_kernel_root_transport_sieve.py
- https://github.com/raosailang-ctrl/egyptian-fractions-complexity/blob/main/research-outputs/weighted_jacobi_code_count.py
- https://github.com/raosailang-ctrl/egyptian-fractions-complexity/blob/main/research-outputs/corrected_group_algebra_mitm.py
- https://github.com/raosailang-ctrl/egyptian-fractions-complexity/blob/main/research-outputs/syndrome_zero_residue_distribution.py

## 最新状态
- https://github.com/raosailang-ctrl/egyptian-fractions-complexity/blob/main/research_state.md
- https://github.com/raosailang-ctrl/egyptian-fractions-complexity/commits/main
